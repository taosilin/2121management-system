<template>

</template>

<script>
export default {
name: "configuration"
}
</script>

<style scoped>

</style>
