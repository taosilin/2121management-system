<template>
  <div>

  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'system',
  data() {
    return {

    }
  },
  created() {
  },
  methods: {

  }
}
</script>

<style scoped>

</style>
